#include<iostream>
using namespace std;
class Rational
{
    public:
    Rational(int a=0,int b=1);
    Rational(const Rational&);
    void print();
    Rational& operator=(const Rational&);
    private:
    int num, den;
    int gcd (int j, int k)
    {
        if (k==0) return j;
        return gcd(k, j%k);
    }

        void reduce ()
        {
            int g = gcd(num, den);
            num /= g;
            den /=g;
        }
};
int main()
{
    Rational x(100,360);
    Rational y(x);
    Rational z, w;
    cout <<"x= "; x.print();
    cout<< "\ny= "; y.print();
    cout<< "\nz= "; z.print();
    w = z = y;
    cout<<"\nz= ";
    z.print();
    cout<<"u\nw= ";
    w.print();
    cout <<"u\n\n\nRress any key to close console window: ";
    char c;
    cin>>c;
    return 0;
}
Rational::Rational (int n, int d)
{ num=n;
 den=d;
reduce();
 }
  Rational::Rational (const Rational& r) : num(r.num), den(r.den)
  {


  }
  void Rational::print()
  {
      cout <<num<<den;

  }


  Rational& Rational::operator= (const Rational &r)
  {
      // // Rational& operator=(const Rational&)
      num= r.num;
       den=r.den;
       return *this;

  }



