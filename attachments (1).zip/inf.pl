go:-write('write the number'),nl,
      read(X),
     write('write another number'),nl,
       read(Y),
        com(X,Y).
com(X,Y):-X>Y,write('X is bigger value');
          write('Y is bigger value').
